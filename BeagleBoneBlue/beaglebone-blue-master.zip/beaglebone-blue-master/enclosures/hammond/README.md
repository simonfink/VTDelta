This enclosure was designed by Hammond Manufacturing. Permission was given to allow BeagleBoard.org to have it manufactured elsewhere.
